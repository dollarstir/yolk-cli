<?php

require __DIR__.'/../core/config.php';
require __DIR__.'/../core/yc.php';
require __DIR__.'/../core/minified.php';
require __DIR__.'/../core/mig.php';
require __DIR__.'/../core/transmitter.php';
require __DIR__.'/../core/PHPMailer/src/Exception.php';
require __DIR__.'/../core/PHPMailer/src/PHPMailer.php';
require __DIR__.'/../core/PHPMailer/src/SMTP.php';
