<?php

class Strong extends YolkUIElement {
    protected $tag = "strong";
}