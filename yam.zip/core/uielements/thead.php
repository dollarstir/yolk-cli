<?php

class THead extends YolkUIElement {
    protected $tag = "thead";
}