<?php

class OptGroup extends YolkUIElement {
    protected $tag = "optgroup";
}