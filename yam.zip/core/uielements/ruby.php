<?php

class Ruby extends YolkUIElement {
    protected $tag = "ruby";
}