<?php

class Rp extends YolkUIElement {
    protected $tag = "rp";
}