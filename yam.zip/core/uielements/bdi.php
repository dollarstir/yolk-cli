<?php

class Bdi extends YolkUIElement {
    protected $tag = "bdi";
}