<?php

class Label {
    protected $tag = "label";
}