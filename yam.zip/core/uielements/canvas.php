<?php

class Canvas extends YolkUIElement {
    protected $tag = "canvas";
}