<?php

class Button extends YolkUIElement {
    protected $tag = "button";
}