<?php

class Frame extends YolkUIElement {
    protected $tag = "frame";
 
}