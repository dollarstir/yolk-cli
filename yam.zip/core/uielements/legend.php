<?php

class Legend {
    protected $tag = "legend";
}