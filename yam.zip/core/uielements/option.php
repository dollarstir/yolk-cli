<?php

class Option extends YolkUIElement {
    protected $tag = "option";
}