<?php

class Code extends YolkUIElement {
    protected $tag = "code";
}