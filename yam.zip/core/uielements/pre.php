<?php

class Pre extends YolkUIElement {
    protected $tag = "pre";
}