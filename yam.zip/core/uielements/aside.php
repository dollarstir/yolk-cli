<?php

class Aside extends YolkUIElement {
    protected $tag = "aside";
}