<?php

class Dt extends YolkUIElement {
    protected $tag = "dt";
}