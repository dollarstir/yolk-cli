<?php

class Kbd extends YolkUIElement {
    protected $tag = "kbd";
}