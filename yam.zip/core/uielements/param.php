<?php

class Param extends YolkUIElement {
    protected $tag = "param";
}