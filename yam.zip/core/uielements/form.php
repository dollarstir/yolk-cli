<?php

class Form extends YolkUIElement {
    protected $tag = "form";
 
}