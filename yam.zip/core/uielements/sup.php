<?php

class Sub extends YolkUIElement {
    protected $tag = "sub";
}