<?php

class Q extends YolkUIElement {
    protected $tag = "q";
}