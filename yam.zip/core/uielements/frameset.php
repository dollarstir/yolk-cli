<?php

class Frameset extends YolkUIElement {
    protected $tag = "frameset";
 
}