<?php

class Script extends YolkUIElement {
    protected $tag = "script";
}