<?php

class Main extends YolkUIElement {
    protected $tag = "main";
}