<?php

class Tr extends YolkUIElement {
    protected $tag = "tr";
}