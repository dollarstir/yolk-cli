<?php

class Ol extends YolkUIElement {
    protected $tag = "ol";
}