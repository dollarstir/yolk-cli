<?php

class Big extends YolkUIElement {
    protected $tag = "big";
}