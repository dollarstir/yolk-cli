<?php

class Mark extends YolkUIElement {
    protected $tag = "mark";
}