<?php

class Acronym extends YolkUIElement {
    protected $tag = "acronym";

}