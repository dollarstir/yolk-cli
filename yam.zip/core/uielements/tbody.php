<?php

class TBody extends YolkUIElement {
    protected $tag = "tbody";
}