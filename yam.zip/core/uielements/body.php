<?php

class Body extends YolkUIElement {
    protected $tag = "body";
}