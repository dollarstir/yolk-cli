<?php

class Dialog extends YolkUIElement {
    protected $tag = "dialog";
}