<?php

class Strike extends YolkUIElement {
    protected $tag = "strike";
}