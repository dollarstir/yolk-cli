<?php

class Html extends YolkUIElement
{
    protected $tag = "html";

}
