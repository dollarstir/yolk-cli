<?php

class Select extends YolkUIElement {
    protected $tag = "select";
}