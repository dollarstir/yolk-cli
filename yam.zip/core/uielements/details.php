<?php

class Details extends YolkUIElement {
    protected $tag = "details";
}