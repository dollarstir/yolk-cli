<?php

class I extends YolkUIElement {
    protected $tag = "i";
 
}