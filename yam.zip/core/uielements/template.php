<?php

class Template extends YolkUIElement {
    protected $tag = "template";
}