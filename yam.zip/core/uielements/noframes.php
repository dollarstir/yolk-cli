<?php

class NoFrames extends YolkUIElement {
    protected $tag = "noframes";
}