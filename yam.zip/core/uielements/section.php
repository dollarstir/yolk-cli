<?php

class Section extends YolkUIElement {
    protected $tag = "section";
}