<?php

class FigCaption extends YolkUIElement {
    protected $tag = "figcaption";
 
}