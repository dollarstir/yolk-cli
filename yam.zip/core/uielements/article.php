<?php

class Article extends YolkUIElement {
    protected $tag = "article";
 
}