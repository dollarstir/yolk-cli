<?php

class Ul extends YolkUIElement {
    protected $tag = "ul";
}