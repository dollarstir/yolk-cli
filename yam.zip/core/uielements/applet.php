<?php

class Applet extends YolkUIElement {
    protected $tag = "applet";
 
}