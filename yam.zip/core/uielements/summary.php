<?php

class Summary extends YolkUIElement {
    protected $tag = "summary";
}