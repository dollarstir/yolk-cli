<?php

class Col extends YolkUIElement {
    protected $tag = "col";
}