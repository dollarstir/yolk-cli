<?php

class Cite extends YolkUIElement {
    protected $tag = "cite";
}