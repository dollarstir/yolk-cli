<?php

class Output extends YolkUIElement {
    protected $tag = "output";
}