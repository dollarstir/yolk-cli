<?php

class Nav {
    protected $tag = "nav";
}