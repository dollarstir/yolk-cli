<?php

class Samp extends YolkUIElement {
    protected $tag = "samp";
}