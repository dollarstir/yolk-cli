<?php

class Abbr extends YolkUIElement {
    protected $tag = "abbr";
 
}