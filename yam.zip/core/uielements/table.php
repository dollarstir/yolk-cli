<?php

class Table extends YolkUIElement {
    protected $tag = "table";
}