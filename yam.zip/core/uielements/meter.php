<?php

class Meter extends YolkUIElement {
    protected $tag = "meter";
}