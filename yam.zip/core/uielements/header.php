<?php

class Header extends YolkUIElement {
    protected $tag = "header";
 
}