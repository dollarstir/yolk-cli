<?php

class Dfn extends YolkUIElement {
    protected $tag = "dfn";
}