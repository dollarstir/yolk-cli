<?php

class Tt extends YolkUIElement {
    protected $tag = "tt";
}