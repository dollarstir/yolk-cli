<?php

class Picture extends YolkUIElement {
    protected $tag = "picture";
}