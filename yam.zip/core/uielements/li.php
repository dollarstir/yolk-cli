<?php

class Li {
    protected $tag = "li";
}