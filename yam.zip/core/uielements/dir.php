<?php

class Dir extends YolkUIElement {
    protected $tag = "dir";
}