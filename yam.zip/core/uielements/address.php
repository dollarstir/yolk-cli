<?php

class Address extends YolkUIElement {
    protected $tag = "address";
}