<?php

class Hr extends YolkUIElement {
    protected $tag = "hr";
    protected $closed = true;
 
}