<?php

class S extends YolkUIElement {
    protected $tag = "s";
}