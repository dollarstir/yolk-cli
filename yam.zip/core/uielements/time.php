<?php

class Time extends YolkUIElement {
    protected $tag = "time";
}