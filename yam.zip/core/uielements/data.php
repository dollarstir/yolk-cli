<?php

class Data extends YolkUIElement {
    protected $tag = "data";
}