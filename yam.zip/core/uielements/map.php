<?php

class Map {
    protected $tag = "map";
}