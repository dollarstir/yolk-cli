<?php

class NoScript extends YolkUIElement {
    protected $tag = "noscript";
}