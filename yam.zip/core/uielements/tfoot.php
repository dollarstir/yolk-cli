<?php

class TFoot extends YolkUIElement {
    protected $tag = "tfoot";
}