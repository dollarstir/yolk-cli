<?php

class Footer extends YolkUIElement {
    protected $tag = "footer";
 
}