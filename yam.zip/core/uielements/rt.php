<?php

class Rt extends YolkUIElement {
    protected $tag = "rt";
}