<?php

class Bdo extends YolkUIElement {
    protected $tag = "bdo";
}