<?php

class Div extends YolkUIElement {
    protected $tag = "div";
}