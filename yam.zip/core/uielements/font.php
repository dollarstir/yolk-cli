<?php

class Font extends YolkUIElement {
    protected $tag = "font";
 
}