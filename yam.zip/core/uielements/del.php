<?php

class Del extends YolkUIElement {
    protected $tag = "del";
}