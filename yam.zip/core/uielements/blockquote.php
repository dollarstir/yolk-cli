<?php

class Blockquote extends YolkUIElement {
    protected $tag = "blockquote";
}