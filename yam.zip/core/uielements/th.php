<?php

class Th extends YolkUIElement {
    protected $tag = "th";
}