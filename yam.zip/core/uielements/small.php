<?php

class Small extends YolkUIElement {
    protected $tag = "small";
}