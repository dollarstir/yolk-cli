<?php

class Caption extends YolkUIElement {
    protected $tag = "caption";
}