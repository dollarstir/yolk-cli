<?php

class U extends YolkUIElement {
    protected $tag = "u";
}