<?php

class Td extends YolkUIElement {
    protected $tag = "td";
}