<?php

class DataList extends YolkUIElement {
    protected $tag = "datalist";
}