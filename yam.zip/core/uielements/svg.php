<?php

class Svg extends YolkUIElement {
    protected $tag = "svg";
}