<?php

class TextArea extends YolkUIElement {
    protected $tag = "textarea";
}