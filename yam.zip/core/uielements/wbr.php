<?php

class Wbr extends YolkUIElement {
    protected $tag = "wbr";
}