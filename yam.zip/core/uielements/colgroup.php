<?php

class ColGroup extends YolkUIElement {
    protected $tag = "colgroup";
}