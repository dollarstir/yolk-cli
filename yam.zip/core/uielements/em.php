<?php

class Em extends YolkUIElement {
    protected $tag = "em";
}