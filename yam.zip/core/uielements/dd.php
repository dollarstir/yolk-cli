<?php

class DD extends YolkUIElement {
    protected $tag = "dd";
}