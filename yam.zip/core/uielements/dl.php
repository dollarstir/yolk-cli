<?php

class Dl extends YolkUIElement {
    protected $tag = "dl";
}