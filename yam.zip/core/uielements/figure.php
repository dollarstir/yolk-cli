<?php

class Figure extends YolkUIElement {
    protected $tag = "figure";
 
}