<?php

class Ins extends YolkUIElement {
    protected $tag = "ins";
}