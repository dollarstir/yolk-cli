<?php
class links{
    
    public static function holder($links=[]){
         require __DIR__ .'/../style.php';
       
        // if (is_array($links)) {
        // } else {
        //     $links = [$links];
        // }
        // $tag = '';
        // foreach($links as $link){
        //    $tag .= $link;
        // }

        // $tag .='';


        // return  require trim($tag);
       


    }
}