<?php

class Dollar
{
    public function doss()
    {
        echo 'my name is dollarstir';
    }
}
