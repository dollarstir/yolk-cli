<?php

$js = [
    el::linkjs('processor/processor.js'),
];

return export($js);
