<?php

$yolkcss = [
    yolkcss('yolkcss/style.php'),
];

return export($yolkcss);
