<?php
/* Yolk migration
 ********************************************************
 * NOTE: what ever is here is what shows in your database.
 *  if you remove a table or a field  and you  lauch the migration route in your browser,
 * it affect your database.
 * *************************************************************************************.
 * to migrate your database tables , open your websitename/migration.
 */
// addtable(
//     'customers',
//     [
//         addColumn('id', 'int', 11, false, true, true),
//         addColumn('fname', 'string', 50, false, false, false),
//         addColumn('lname', 'string', 50, false, false, false),
//         addColumn('email', 'string', 50, false, false, false),
//         addColumn('phone', 'string', 50, false, false, false),
//         addColumn('gender', 'string', 50, false, false, false),
//         addColumn('dob', 'string', 50, false, false, false),
//         addColumn('password', 'string', 50, false, false, false),
//     ]
// );

// addtable('category', [
//     addColumn('id', 'int', 11, false, true, true),
//     addColumn('catname', 'string', 100, false, false, false),
// ]);
